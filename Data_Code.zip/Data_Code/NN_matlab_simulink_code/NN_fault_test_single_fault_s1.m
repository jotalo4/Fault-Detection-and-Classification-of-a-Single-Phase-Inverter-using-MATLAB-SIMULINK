clear
close all

% parameters
%FT = 0.03 * rand() + 0.05;
FT = 0.03 * rand();
s1_set = 2; % 2=no fault, 1=fault short, 0=fault open
s2_set = 2;
s3_set = 2;
s4_set = 2;
my_max = 100; % number of times to train NN

% Capture multiple data sets under the same fault condition with random
% fault time and random measurement error.  Write to data file after each
% iteration.

fileID = fopen('NN_data_test_s4_new.txt','r');
formatSpec = '%f %f %f %f %f %f %f %f %f %f %d %d %d %d %f';
A = fscanf(fileID,formatSpec, [15 Inf]);
fclose(fileID);
A = A'; % data read in transposed
X = A(:,1:10); % PSD data only
fault_device = A(:,11:14); % fault condition for each MOSFET

% NN Config
[N1,N2] = size(X);
Onod = 3; % 3 output nodes representing the 3-classes: 0 1 and 2
Inod = N2; % nodes of each training data
N = N1; % length of training data
my_pick=4;

% Choose
%DI = fault_device(:,1);
%DI = fault_device(:,2);
%DI = fault_device(:,3);
DI = fault_device(:,4);

% output encoding
D = zeros(N,Onod);
for id = 1:N
    if DI(id) == 0
        D(id,:) = [1 0 0];
    elseif DI(id) == 1
        D(id,:) = [0 1 0];
    elseif DI(id) == 2
        D(id,:) = [0 0 1];
    end
end


%CC = 0;  % initialize counter
Y = zeros(N,Onod);
 for k = 1:N
        x = X(k,:)';
        d = D(k,:)'; 
        y = Y(k,:)';
 end
 
% train
horizon = 100; % number of times to train NN
%E1 = zeros(horizon, 1); % error metric
Cid = zeros(horizon, 1); % error metric
PCid = zeros(horizon, 1); % error metric

for epoch=1:horizon
    % start simulation
    %FT = 0.03 * rand() + 0.05; % new random fault time
     FT = 0.03 * rand();
    
 % Choose Switch
    if (my_pick == 1)
       s1_set = randi([0 2]); % 2=no fault, 1=fault short, 0=fault open
    end
    if (my_pick == 2)
       s2_set = randi([0 2]); % 2=no fault, 1=fault short, 0=fault open
    end
    if (my_pick == 3)
       s3_set = randi([0 2]); % 2=no fault, 1=fault short, 0=fault open
    end
    if (my_pick == 4)
        s4_set = randi([0 1]); % 2=no fault, 1=fault short, 0=fault open
    end
    
    sim('NN_fault_detection_data_generator.slx')
    %current_data = ans.voltage_measured.Data + randn(length(ans.voltage_measured.Data), 1); % measurement error
    current_data = ans.voltage_measured.Data;
    [pxx,w] = pwelch(current_data, 100, [], 18);
    plot(w/pi,10*log10(pxx))
    xlabel('\omega / \pi')

    %hold on
    %fprintf(fileID,'%6.2f %6.2f %6.2f %6.2f %6.2f %6.2f %6.2f %6.2f %6.2f %6.2f ', 10*log10(pxx));
    %fprintf(fileID,'%d %d %d %d %6.2f\r\n',s1_set,s2_set,s3_set,s4_set,FT);

    % compute fault condition from converged weights
    W1 = [-0.4828    1.5255    0.3194    0.2709;
    0.7805   -0.5050    1.1311   -0.2622;
    0.9748   -0.3946    1.2025    1.8729;
    0.4588   -0.3716    0.5697    1.6992;
   -1.0789   -0.7043    0.0953   -0.9548];

    W2 = [0.2759    2.3017   -0.2665    0.1727   -0.7539;
   -0.3425    0.0772   -0.7211    0.5303   -0.3555;
    0.8047    0.3725   -1.1098    1.6560    0.8571;
    0.9359    0.1706    0.1175    0.4397    0.9844];
    
    b2 = [0.7794 2.3354 1.1271 1.0271]';

    b1 = [-0.8373 0.5293 0.8731 0.1819 -1.0386]';
   
    i_size = 4; % length of input vector
    o_size = 4; % length of output vector
    p_base = [27.8757; -11.7624; -5.5133; -16.1126; -21.8011; -21.8238; -22.4124; -19.8479; -20.6705; -28.2811]';
    p_base = p_base(1:i_size);

    T = 10*log10(pxx);
    % compute output of hidden layer
    P = T(1:i_size)' - p_base;
    my_temp = W1 * P' + b1;
    a1 = 1 ./ (1 + exp(-my_temp));

    % compute output of output layer
    my_temp = W2 * a1 + b2;
    a2 = my_temp;

   
  % percentage of correct fault identification
    for k = 1:N
        for id = 1:3
            if abs(a2(1)) < 0.55 && abs(a2(1)) >= 0
                Y(k,id) = 0;
            elseif abs(a2(1)) <= 1 && abs(a2(1)) >= 0.55
                Y(k,id) = 1;
            end
        end
        if norm(D(k,:)-Y(k,:)) == 0
            Cid(epoch) = Cid(epoch) + 1;
        end
    end
    PCid(epoch) = (Cid(epoch) / N ) * 100;
    
end

%hold off
%CC/my_max
plot(PCid, 'b')
xlabel('Epoch')
ylabel('Correct Identification (%)')
legend('PSD NN')

%fclose(fileID);



